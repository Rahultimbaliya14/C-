<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://kit.fontawesome.com/0f900b0930.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../Css/About/about.css">
    <link rel="shortcut icon" href="../Images/LOGO.png" type="image/x-icon">
     <link rel="stylesheet" href="../Css/Devloper.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <section class="about">
        <div class="main">
         <img src="../Images/Mihir.jpg" alt="">
            <div class="about-text">
                <h1>Mihir Vaddoriya</h1>
                <h5>About My Self  & <span class="span1">Contacts</span></h5>
                <p>I am a student of DSTC and currently studying BCA.
                    I love to explore new approaches in world of programming,
                    It is the most satisfying feeling for me to solve conundrums of DSA.
                    <hr></hr>
                </p>
                    <div class="tecr">
                        <div class="email">
                            <i class="fa-solid fa-location-dot"></i>
                          
                        </div>
                        <div class="text">
                          Dhari, Amreli 365640
                           
                          </div>
                        </div>
                     <br>
                  <div class="tecr">
                    <div class="email">
                    <i class="fa-solid fa-envelope"></i>
                      
                    </div>
                    <div class="text">
                        mp13.vaddoriya@gmail.com
                       
                      </div>
                </div>
            
                <br>
                <div class="tecr">
                    <div class="email">
                        <i class="fa-solid fa-phone"></i>
                      
                    </div>
                    <div class="text">
                        +91 743-306-3127
                      </div>
                </div>
                    
                  <br>
                  <br>
                <div class="line">
                <div class="buton">
                    <a href="https://instagram.com/mihirpatel_13?igshid=YmMyMTA2M2Y="><i class="fa-brands fa-instagram"></i></a></i>
                </div>
                <div class="buton">
                    <a href="https://wa.me/+917433063127">
                        <i class="fa-brands fa-whatsapp"></i></a>
                </div>
                <div class="buton">
                    <a href="https://www.facebook.com/profile.php?id=100037812103759">
                    <i class="fa-brands fa-facebook"></i></a></a>
                </div>
                <div class="buton">
                    <a href="https://twitter.com/MIHIR_PATEL_13?t=OI2VFl9KZGnOaiK6D0QBsg&s=08">
                    <i class="fa-brands fa-twitter"></i></a>
                </div>
            </div>
            </div>
        </div>
        <br>
        <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button><a href="../Views/Devloper.php">...Privious</a></button> 
    &nbsp;&nbsp;&nbsp;&nbsp;<button><a href="../Views/Devloper3.php">Next...</a></button>     
    </section>
   
</body>

</html>