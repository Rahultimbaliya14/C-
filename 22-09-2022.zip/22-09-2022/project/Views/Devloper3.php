<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://kit.fontawesome.com/0f900b0930.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../Css/About/about.css">
    <link rel="shortcut icon" href="../Images/LOGO.png" type="image/x-icon">
     <link rel="stylesheet" href="../Css/Devloper.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <section class="about">
        <div class="main">
         <img src="../Images/IMG_20211102_155004_624.jpg" alt="">
            <div class="about-text">
                <h1>Manish Parmar</h1>
                <h5>About My Self  & <span class="span1">Contacts</span></h5>
                <p>Hi.... My Name Is Manish Parmar.
                    Study At Dr.Shubhash University -Junagadh
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam enim quae commodi voluptatibus quas odit voluptatum quibusdam incidunt tenetur blanditiis aperiam, fugiat placeat voluptas suscipit architecto mollitia, eius distinctio quisquam.
                    <div class="tecr">
                        <div class="email">
                            <i class="fa-solid fa-location-dot"></i>
                          
                        </div>
                        <div class="text">
                           Jetlavad, Visavadar
                           
                          </div>
                        </div>
                     <br>
                  <div class="tecr">
                    <div class="email">
                    <i class="fa-solid fa-envelope"></i>
                      
                    </div>
                    <div class="text">
                        ParmarManish2814@gmail.com
                       
                      </div>
                </div>
            
                <br>
                <div class="tecr">
                    <div class="email">
                        <i class="fa-solid fa-phone"></i>
                      
                    </div>
                    <div class="text">
                        +91  958-629-4101
                      </div>
                </div>
                    
                  <br>
                  <br>
                <div class="line">
                <div class="buton">
                    <a href="http://instagram.com/manish_khopri?igshid=YmMyMTA2M2Y="><i class="fa-brands fa-instagram"></i></a></i>
                </div>
                <div class="buton">
                    <a href="https://wa.me/+919586294101">
                        <i class="fa-brands fa-whatsapp"></i></a>
                </div>
            </div>
            </div>
        </div>
        <br>
        <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button><a href="../Views/Devloper2.php">...Privious</a></button>   
    </section>
   
</body>

</html>