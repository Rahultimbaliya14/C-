<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="../Css/About/about.css">
    <link rel="shortcut icon" href="../Images/LOGO.png" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    include('../includes/navbar.php');
    ?>
    <section class="about">
        <div class="main">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2565.9290496214267!2d70.46575251365834!3d21.540042075505824!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3958023ace980a4b%3A0xf428a8d5c135bd09!2sSakkarbaug%20Zoological%20Park!5e1!3m2!1sen!2sin!4v1662917412656!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <div class="about-text">
                <h1>About-Us</h1>
                <h5>About Zoo & <span class="span1">Information</span></h5>
                <p><h2>Hellow User Thanks For Visiting This Website</h2>
                <br>
                      <h3>In This Website You Can Find All Over The Information About The Zoo</h3>
                      <h3>We Can Always For You And Working To Inhance Your Expriance</h3> 
                      <h3>For Any Query You Can Contact-Us</h3>
                </p>
                <button type="button"><a href="../Views/Contact.php">Contact-Us</a></button>
            </div>
        </div>
    </section>
    <?php
    include('../includes/footer.php');
    ?>

</body>

</html>