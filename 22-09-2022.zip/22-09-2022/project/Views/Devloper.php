<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://kit.fontawesome.com/0f900b0930.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../Css/About/about.css">
    <link rel="shortcut icon" href="../Images/LOGO.png" type="image/x-icon">
     <link rel="stylesheet" href="../Css/Devloper.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <section class="about">
        <div class="main">
         <img src="../Images/IMG_20220817_230424_284.jpg" alt="">
            <div class="about-text">
                <h1>Rahul Timbaliya</h1>
                <h5>About My Self  & <span class="span1">Contacts</span></h5>
                <p>Hi.... My Name Is Rahul Timbaliya.
                    Study At DSTC -Junagadh.
                    I love to explore new approaches in world of programming,
                    It is the most satisfying feeling for me to solve conundrums of DSA.
                    <hr>
                    <div class="tecr">
                        <div class="email">
                            <i class="fa-solid fa-location-dot"></i>
                          
                        </div>
                        <div class="text">
                          Dhari, Amreli 365640
                           
                          </div>
                        </div>
                     <br>
                  <div class="tecr">
                    <div class="email">
                    <i class="fa-solid fa-envelope"></i>
                      
                    </div>
                    <div class="text">
                       RahulTimballiya555@gmail.com
                       
                      </div>
                </div>
            
                <br>
                <div class="tecr">
                    <div class="email">
                        <i class="fa-solid fa-phone"></i>
                      
                    </div>
                    <div class="text">
                        +91  635-364-7592
                      </div>
                </div>
                    
                  <br>
                  <br>
                <div class="line">
                <div class="buton">
                    <a href="http://instagram.com/rahultimbaliya?igshid=YmMyMTA2M2Y="><i class="fa-brands fa-instagram"></i></a></i>
                </div>
                <div class="buton">
                    <a href="https://wa.me/+916353647592">
                        <i class="fa-brands fa-whatsapp"></i></a>
                </div>
                <div class="buton">
                    <a href="https://www.facebook.com/rahul.timbaliya">
                    <i class="fa-brands fa-facebook"></i></a>
                </div>
                <div class="buton">
                    <a href="https://github.com/Rahultimbaliya14">
                    <i class="fa-brands fa-github"></i></a>
                </div>
                <div class="buton">
                    <a href="https://www.linkedin.com/in/rahul-timbaliya-55672023b">
                    <i class="fa-brands fa-linkedin"></i></a>
                </div>
                <div class="buton">
                    <a href="https://rahultimbaliya.wordpress.com/">
                    <i class="fa-solid fa-earth-americas"></i></a>
                </div>
            </div>
            </div>
        </div>
        <br>
        <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button><a href="../Views/Devloper2.php">Next...</a></button>   
    </section>
   
</body>

</html>