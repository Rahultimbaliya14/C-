<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="../Images/LOGO.png" type="image/x-icon">
        <link rel="stylesheet" href="../Css/Gallary/videos.css">
        <title>Document</title>
</head>

<body>
        <?php
        include('../includes/navbar.php')
        ?>
        <div class="container gy-3">
        <iframe width="360" height="230" src="https://www.youtube.com/embed/XHSeDZynVWk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </iframe>
                <iframe width="360" height="230" src="https://www.youtube.com/embed/dMD0YiZ_24s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <iframe width="360 " height="230" src="https://www.youtube.com/embed/l6BYM5Mvq6A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

        </div>
        <br><br>
        <hr>
        <div class="container">
        <iframe width="360" height="230" src="https://www.youtube.com/embed/8Nz7AEDZo6c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

        <iframe width="360" height="230" src="https://www.youtube.com/embed/VSbqZsML5JI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>


        <iframe width="360" height="230" src="https://www.youtube.com/embed/DLl6NumVG7I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

        </div>
        <?php
        include('../includes/footer.php');
        ?>
</body>

</html>