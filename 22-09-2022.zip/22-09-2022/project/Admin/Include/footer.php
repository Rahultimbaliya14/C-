<link rel="stylesheet" href="../Css/home.css">
<div class="footer">
                <img src="../Images/Footer.png" alt="footer">
</div>
<div class="mainfotter">

</div>