<?php
include("../Include/dbconnect.php");
$query="SELECT email from user3";
$result=mysqli_query($con,$query);
?>
<?php
if(isset($_GET['submit'])){
    $name=$_GET['Name'];
    $pass=1;
    $email=$_GET['email'];
    $mobile=$_GET['mobile'];
    $address=$_GET['address'];
    $password=$_GET['password'];   
    if(empty($name)){
        header("location: ../View/Adduser.php?error=Name Is Require");
    }
    else if(empty($email)){
        header("location: ../View/Adduser.php?error=Email Is Require");
    }
    else if(empty($mobile)){
        header("location: ../View/Adduser.php?error=Mobile No Is Require");
    }
    else if(empty($address)){
        header("location: ../View/Adduser.php?error=Address Is Require");
    }
    else if(empty($password)){
        header("location: ../View/Adduser.php?error=Password Is Require");
    }
    else{
      while($row=mysqli_fetch_array($result)){
        if($row['email']==$email){
            header("location: ../View/Adduser.php?error=User Already Exist");   
            $pass=2;
            exit();
            break;
        }
        else{
            $pass=3;
        }
    }
        if($pass==3){
           $haspassword=password_hash($password,PASSWORD_DEFAULT);
          $query2="INSERT INTO user3(name,email,mobileno,address,password) VALUES('$name','$email','$mobile','$address','$haspassword')";
            $result2=mysqli_query($con,$query2);
            if($result2){
                echo "<script>alert('hellow')</script>";
                header("location: ../View/Adduser.php?s=1");
            }
            else{
                echo "hello";
            }
            }
       
  
}
}
   
?>