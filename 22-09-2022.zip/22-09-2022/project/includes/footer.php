<link rel="stylesheet" href="../Css/Home/Navbar.css">
<div class="footer">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <img src="../Images/FOOTER" alt="">
  </div>
  <div class="mainfooter">
  </div>
  <div class="devloper">
    <marquee behavior="alternate" direction="right"><i class="fa-regular fa-copyright"></i>About The Devloper&nbsp; &nbsp;<a href="../Views/Devloper.php">Click hare</a></marquee>
  </div>