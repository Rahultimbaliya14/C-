
<script src="https://kit.fontawesome.com/0f900b0930.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="../Css/Home/Navbar.css">
<link rel="stylesheet" href="../Css/About/about.css">
<div class="nav">
    <nav class="bar">

      <div class="nav_logo">
        <img src="../Images/LOGO.png" alt="logo" class="logo" href="index.html">
        <h4>It'<sup>s</sup><span>Zoo</span></h4>
      </div>
      <ul>
        <li><a href="../Views/index.php" class="first"><i class="bi bi-house-door-fill"></i>&nbsp;Home</a></li>
        <li><a href="About.php"><i class="bi bi-info-circle-fill"></i>&nbsp;About</a></li>
        <li><i class="fa-brands fa-envira"></i><a href="gallary.php" >Gallary</a></li>
        <li><a href="../Views/videos.php"><i class="fa-solid fa-circle-play"></i>Videos</a></li>
        <li><a href="Contact.php" ><i class="bi bi-person-lines-fill"></i>&nbsp;Contact Us</a></li>
      </ul>

      <a href="../Views/Book.php?s=0" class="nav_book">Book</a>
      <?php
     
      ?>
    </nav>

  </div>
  <script>
 
      

  </script>